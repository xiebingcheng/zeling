<?php
header('Content-Type:text/html; charset=gb2312');
echo $_POST['name']."king";
?>